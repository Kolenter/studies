public class fact {
    public static int a = 1;
    public static int b = 3;
    public static int c = 9;
    public static int d = 27;

    public static void main(String[] args) {

        int result = + a + b + c + d;

        System.out.println(result);
    }
}